var aws = require('aws-sdk');
var ecs = new aws.ECS();


exports.handler = (event, context, callback) => {
    
  aws.config.update({
    region: event.region
  });
  console.log('container image: ', event.dockerImage)
  //broker params
  var broker_params = {
    "containerDefinitions": [
    {
      "name": "broker",
      "image": "" + event.dockerImage + "",
      "cpu": 10,
      "memory": 4096,
      "readonlyRootFilesystem": false,
      "environment": [
        {
          "name": "NODE_REGION",
          "value": "" + event.region + ""
        },
        {
          "name": "ENV_TYPE",
          "value": "AWSECS"
        },
        {
          "name": "AGENT_PORT",
          "value": "48011"
        },
        {
          "name": "BROKER_PORT",
          "value": "48004"
        },
        {
          "name": "NODE_PORT",
          "value": "48010"
        },
        {
          "name": "NODE_TYPE",
          "value": "BROKER"
        },
        {
            "name": "PEER_ADDRESS",
            "value": "" + event.peer_address + ":48004"
        }
      ],
      "essential": true,
      "portMappings": [
        {
          containerPort: 48004,
          hostPort: 48004,
          protocol: "tcp"
        }
      ],
    }
  ],
  "family": "broker",
  "taskRoleArn": "" + event.role + ""
  };
  
  ecs.registerTaskDefinition(broker_params, function(err, data) {
    if (err) { 
        console.log('Broker definition error: ', err, err.stack);
    } else {
        console.log('Broker definition created: ', data)
        
            //create service group for broker
    var params = {
      desiredCount: 1, /* required */
      serviceName: "nuodb-broker-service",
      taskDefinition: "broker",
      cluster: "" + event.cluster + "",
/*      deploymentConfiguration: {
        maximumPercent: 0,
        minimumHealthyPercent: 0
      },
*/
/*    loadBalancers: [
      {
        containerName: 'broker',
        containerPort: 48004,
        loadBalancerName: 'bhiggins-ecs-test'
      }
    ],
*/
    placementStrategy: [
      {
        field: 'instanceId',
        type: 'spread'
      }
    ],
//    role: "" + event.role + ""
  };
  ecs.createService(params, function(err, data) {
    if (err) console.log('Create Service for Broker failed: ', err, err.stack); // an error occurred
    else     console.log('Create Service for Broker successful: ', data);           // successful response
  });
  
    }
  });
 
  
  
  //create sm task definition
    var sm_params = {
    "containerDefinitions": [
    {
      "name": "sm",
      "image": "" + event.dockerImage + "",
      "cpu": 10,
      "memory": 4096,
      "readonlyRootFilesystem": false,
      "environment": [
        {
          "name": "NODE_REGION",
          "value": "" + event.region + ""
        },
        {
          "name": "ENV_TYPE",
          "value": "AWSECS"
        },
        {
          "name": "AGENT_PORT",
          "value": "48011"
        },
        {
          "name": "NODE_PORT",
          "value": "48010"
        },
        {
          "name": "NODE_TYPE",
          "value": "SM"
        },
        {
            "name": "PEER_ADDRESS",
            "value": "" + event.peer_address + ":48004"
        },
        {
            "name": "DB_NAME",
            "value": "db1"
        }
      ],
      "essential": true
    }
  ],
  "family": "sm"
  };
  
  ecs.registerTaskDefinition(sm_params, function(err, data) {
    if (err) console.log('Create SM task definition failed: ', err, err.stack); // an error occurred
    else     console.log('Create SM task definitio successful: ', data);           // successful response
  });
  
    //create sm task definition
    var te_params = {
    "containerDefinitions": [
    {
      "name": "te",
      "image": "" + event.dockerImage + "",
      "cpu": 10,
      "memory": 4096,
      "readonlyRootFilesystem": false,
      "environment": [
        {
          "name": "NODE_REGION",
          "value": "" + event.region + ""
        },
        {
          "name": "ENV_TYPE",
          "value": "AWSECS"
        },
        {
          "name": "AGENT_PORT",
          "value": "48011"
        },
        {
          "name": "NODE_PORT",
          "value": "48010"
        },
        {
          "name": "NODE_TYPE",
          "value": "TE"
        },
        {
            "name": "PEER_ADDRESS",
            "value": "" + event.peer_address + ":48004"
        },
        {
            "name": "DB_NAME",
            "value": "db1"
        }
      ],
      "essential": true
    }
  ],
  "family": "te"
  };
  
  ecs.registerTaskDefinition(te_params, function(err, data) {
    if (err) console.log('Create TE task definition failed: ', err, err.stack); // an error occurred
    else     console.log('Create TE task definition successful: ', data);           // successful response
  });

  
};